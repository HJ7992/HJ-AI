import streamlit as st
import time
import pandas as pd
import numpy as np

st.set_page_config(
    page_title='缓存机制演示',
    page_icon='⚡',
    layout='wide',
)

st.title('⚡ Streamlit 缓存机制演示')
st.caption('每次点击按钮或拖拽滑块都会触发页面重跑(rerun)，观察各区域的耗时变化')

# ============================================================
# 侧边栏：全局控制
# ============================================================
with st.sidebar:
    st.header('⚙️ 全局控制')
    st.markdown('修改以下参数后观察缓存行为变化')
    cache_ttl = st.slider('cache_data TTL (秒)', 1, 60, 10, help='缓存的存活时间，超时后自动失效')
    clear_cache = st.button('\U0001f5d1️ 清除所有缓存', help='手动清除 @st.cache_data 和 @st.cache_resource 的缓存')


# ============================================================
# 1. @st.cache_data — 数据缓存
# ============================================================
st.divider()
st.header('1⃣ @st.cache_data — 数据缓存')
st.markdown('适合缓存 **数据**：DataFrame、API 响应、计算结果等。数据量小时存于内存，数据量大时自动序列化到磁盘。')

col1, col2 = st.columns(2)

with col1:
    st.subheader('\U0001f4e6 生成随机数据表')

    if clear_cache:
        st.cache_data.clear()

    @st.cache_data(ttl=cache_ttl, show_spinner='正在生成数据...')
    def generate_dataframe(rows: int, cols: int) -> pd.DataFrame:
        """模拟一个耗时的数据生成操作"""
        time.sleep(2)  # 模拟耗时操作
        data = np.random.randn(rows, cols)
        return pd.DataFrame(data, columns=[f'列_{c}' for c in range(cols)])

    rows = st.slider('行数', 100, 5000, 1000, 100, key='cache_data_rows')
    cols = st.slider('列数', 3, 20, 5, key='cache_data_cols')

    t0 = time.time()
    df = generate_dataframe(rows, cols)
    elapsed = (time.time() - t0) * 1000

    if elapsed < 50:
        st.success(f'✅ 缓存命中！耗时 {elapsed:.1f} ms')
    else:
        st.warning(f'⏳ 缓存未命中（重新计算），耗时 {elapsed:.1f} ms')

    st.dataframe(df, width='stretch')

with col2:
    st.subheader('\U0001f4c8 模拟慢速 API 调用')

    @st.cache_data(ttl=cache_ttl, show_spinner='正在请求API...')
    def fetch_api_data(api_endpoint: str, delay: float) -> dict:
        """模拟一个耗时的 API 请求"""
        time.sleep(delay)
        return {
            'endpoint': api_endpoint,
            'status': 200,
            'payload': list(np.random.randint(1, 100, 8)),
            'timestamp': time.strftime('%H:%M:%S'),
        }

    api_options = {
        '/api/users': 1.5,
        '/api/orders': 2.0,
        '/api/products': 1.0,
        '/api/stats': 2.5,
    }
    selected_api = st.selectbox('选择 API 端点', list(api_options.keys()), key='api_select')
    api_delay = api_options[selected_api]

    t0 = time.time()
    result = fetch_api_data(selected_api, api_delay)
    elapsed = (time.time() - t0) * 1000

    if elapsed < 50:
        st.success(f'✅ 缓存命中！耗时 {elapsed:.1f} ms')
    else:
        st.warning(f'⏳ 缓存未命中（请求了 API），耗时 {elapsed:.1f} ms')

    st.json(result)

    st.info(f'\U0001f4a1 **TTL = {cache_ttl}s**：超过这个时间后缓存自动失效，下次请求会重新计算。')


# ============================================================
# 2. @st.cache_resource — 资源缓存
# ============================================================
st.divider()
st.header('2⃣ @st.cache_resource — 资源缓存')
st.markdown('适合缓存 **不可序列化的资源**：数据库连接、ML 模型、线程池等。此缓存没有 TTL，只在应用重启或手动清除时失效。')

col3, col4, _ = st.columns([1, 1, 0.3])

with col3:
    st.subheader('\U0001f916 模拟 ML 模型加载')

    @st.cache_resource(show_spinner='正在加载模型...')
    def load_model(model_name: str):
        """模拟加载一个大型 ML 模型"""
        time.sleep(2)
        return {
            'name': model_name,
            'loaded_at': time.strftime('%H:%M:%S'),
            'params': f'{np.random.randint(10, 500)}M',
        }

    model_choice = st.radio(
        '选择模型',
        ['BERT-base', 'GPT-small', 'ResNet-50', 'YOLO-tiny'],
        horizontal=True,
        key='model_radio',
    )

    t0 = time.time()
    model = load_model(model_choice)
    elapsed = (time.time() - t0) * 1000

    if elapsed < 50:
        st.success(f'✅ 资源已缓存！加载耗时 {elapsed:.1f} ms')
    else:
        st.warning(f'⏳ 首次加载模型，耗时 {elapsed:.1f} ms')

    st.json(model)

with col4:
    st.subheader('\U0001f517 模拟数据库连接')

    @st.cache_resource(show_spinner='正在连接数据库...')
    def get_db_connection(db_name: str):
        """模拟建立数据库连接"""
        time.sleep(1.5)
        return {
            'db': db_name,
            'connected': True,
            'conn_id': np.random.randint(10000, 99999),
        }

    db_choice = st.selectbox('选择数据库', ['PostgreSQL', 'MySQL', 'MongoDB', 'Redis'], key='db_select')

    t0 = time.time()
    conn = get_db_connection(db_choice)
    elapsed = (time.time() - t0) * 1000

    if elapsed < 50:
        st.success(f'✅ 连接已缓存！耗时 {elapsed:.1f} ms')
    else:
        st.warning(f'⏳ 首次建立连接，耗时 {elapsed:.1f} ms')

    st.json(conn)


# ============================================================
# 3. st.session_state — 会话状态
# ============================================================
st.divider()
st.header('3⃣ st.session_state — 会话状态')
st.markdown('**session_state 不是缓存**，而是跨 rerun 持久化的状态字典。适合存：计数器、表单输入、用户偏好等。')

col5, col6 = st.columns(2)

with col5:
    st.subheader('\U0001f522 计数器（跨 rerun 保持）')

    if 'counter' not in st.session_state:
        st.session_state.counter = 0

    c1, c2, c3 = st.columns([1, 1, 2])
    c1.button('\U0001f7e2 +1', on_click=lambda: st.session_state.update(counter=st.session_state.counter + 1))
    c2.button('\U0001f534 清零', on_click=lambda: st.session_state.update(counter=0))

    st.metric('当前计数值', st.session_state.counter)
    st.caption(f'页面已重跑 **{st.session_state.counter + 1}** 次（含本次）')

with col6:
    st.subheader('\U0001f4dd 表单输入保持')

    if 'submitted_data' not in st.session_state:
        st.session_state.submitted_data = []

    with st.form('my_form'):
        name = st.text_input('姓名')
        value = st.number_input('数值', 0, 100, 50)
        if st.form_submit_button('提交'):
            st.session_state.submitted_data.append({'name': name, 'value': value, 'time': time.strftime('%H:%M:%S')})

    if st.session_state.submitted_data:
        st.dataframe(pd.DataFrame(st.session_state.submitted_data), width='stretch')
    else:
        st.caption('还没有提交数据')
