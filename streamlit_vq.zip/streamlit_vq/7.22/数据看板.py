import pandas as pd
import numpy as np
import streamlit as st
from datetime import datetime,timedelta
st.set_page_config(
    page_title = '销售数据看板',
    layout = 'wide',
)
st.header('数据看板')
st.markdown('实时查看业务数据的趋势分析')

#生成实例数据
@st.cache_data
def generate_data():
    datas = pd.date_range(end=datetime.today(),periods=100,freq='D')
    np.random.seed(42)
    data = pd.DataFrame({
        "日期": datas,
        "销售额": np.random.randint(5000,50000,100),
        "订单数": np.random.randint(50,500,100),
        "客户数": np.random.randint(20,200,100),
        "转化率": np.random.randint(0.02,0.15,100),
    })
    return data
df = generate_data()

#侧边栏
st.sidebar.header('筛选条件')
date_range = st.sidebar.date_input(
"日期范围",
[df['日期'].min().date(),df['日期'].max().date()]
)
if len(date_range) ==2:
    start_date,end_date = date_range
    mask = (df['日期'].dt.date)&(df['日期'].dt.date<=end_date)
    filtered_df = df[mask].copy()
else:
    filtered_df = df.copy()

st.subheader('核心指标')
col1,col2,col3,col4 = st.columns(4)
with col1:
    total = filtered_df['销售额'].sum()

    delta_sal = total*0.12

    st.metric(
        label = '总销售额',
        value = f'{total:,.0f}',
        delta = f'+{total:,.0f}',
    )
with col2:
    total_oders = filtered_df['订单数'].sum()

    delta_oders = total_oders * 0.12

    st.metric(
        label = '订单数',
        value = f'{total_oders:,.0f}',
        delta = f'+{delta_oders:,.0f}',
    )
with col3:
    total_cus = filtered_df['客户数'].sum()

    delta_cus = total * 0.03

    st.metric(
        label = '客户数',
        value = f'{total_cus:,.0f}',
        delta = f'+{delta_cus:,.0f}',
        delta_color = 'inverse',
    )
with col4:
    avg = filtered_df['转化率'].mean()

    delta_ag = 0.02

    st.metric(
        label = '平均转化率',
        value = f'{avg:.2%}',
        delta = f'+{delta_ag:.2%}',
    )
col_char1,col_char2= st.columns(2)
with col_char1:
    st.subheader('销售额趋势')
    chart_df = filtered_df.set_index('日期')[['销售额']]
    st.line_chart(chart_df,width = 'content')