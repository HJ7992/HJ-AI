import streamlit as st
from  datetime import datetime,timedelta,time

############交互组件详解
st.set_page_config(
    page_title="Streamlit Demo",
    page_icon = '',
    layout="wide"
)
st.title("交互组件详解")
st.markdown("探索streamlit的组件输入")

########标签页,区分不同类型的组件
tab1,tab2,tab3,tab4 = st.tabs(["文本输入","选择组件","日期时间","文件上传"])
with tab1:
    st.header('文本输入组件')

    col1,col2= st.columns(2)
    with col1:
        st.subheader('单行文本')
        text_input = st.text_input(
            label = '你的名字',placeholder = '请输入你的名字'
        )
        if text_input:
            st.write(f'你好{text_input}')
        st.header('多行文本')
        text_area = st.text_area(
            label = '多行文本',placeholder = "这里写多行文本"
        )
        if text_area:
            st.write(f'你好{len(text_area)}')
        st.subheader("密码输入")
        password = st.text_input(
            label = '密码',type = 'password',placeholder = '请输入密码'
        )
        if password:
            st.write('密码已输入')

    with col2:
        st.header('数字输入')
        number = st.number_input(label = '选择数字',min_value = 1,max_value = 100,value = 50)
        st.write(f'你输入的数字是{number}')

        st.subheader("滑块")
        slider = st.slider(
            label = '滑块选择',min_value = 1,max_value = 100,value = 50
        )
        st.write(f'{slider}')

        st.subheader("范围选择")
        range = st.slider(
            label = '范围选择' ,min_value = 1,max_value = 100,value = (20,60)
        )
with tab2:
    st.header('选择组件')
    col1,col2 = st.columns(2)
    with col1:
        st.subheader('下拉选择')
        option = st.selectbox('选择水果',options = ['苹果','香蕉','兔子','水果','苹果',])
        st.write(f'{option}')

        st.subheader('多选择')

        options =  st.multiselect(
            label = '选择你喜欢的运动',
            options = ["qwe","asd","zxc","tyu",]
        )
        st.write(f'{options}')

    with col2:
        st.subheader('单选按钮')
        radio_val = st.radio(
            label = '打分',
            options = ['1','11','111','1111','11111',]
        )
        st.write(f'{radio_val}')


with tab3:
    st.header("日期时间")

    col1,col2 = st.columns(2)
    with col1:
        st.subheader("日期选择")
        date = st.date_input(
            label = '选择日期',
            value =  datetime.today()
        )
        st.write(f'{date}')

        st.subheader('日期范围')
        date1 = st.date_input(
            label = '选择日期范围',
            value = [datetime.today(),datetime.today()+timedelta(days=7)]
        )
        st.write(f'{date1[0]}________{date1[1]}')
    with col2:
        st.subheader("时间选择")
        time_val = st.time_input(
            label = '设置时间',
            value = time()
        )
        st.write(f'{time_val}')
with tab4:
    st.header("文件上传")
    st.subheader("上传单个文件")
    up_file = st.file_uploader(
        label = '选择文件',
        type = ['csv','txt','pdf'],
        help = "支持csv,txt,pdf"
    )
    if up_file:
        st.success(f'{up_file.name}上传成功')
        st.write(f'大小{up_file.size}')
        if up_file.type=='txt':
            st.text(up_file.read().decode())
    st.divider()

    st.subheader("上传单个文件")
    up_files = st.file_uploader(
        label = '选择文件',
        accept_multiple_files = True,
    )
    if up_files:
        st.write(f"刚上传了{len(up_files)}")
        for file in up_files:
            st.write(file.name)


