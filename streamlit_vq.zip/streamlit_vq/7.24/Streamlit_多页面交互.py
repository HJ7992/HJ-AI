import streamlit as st
st.set_page_config(
    page_title=" 购物车演示",
    page_icon=":🛒",
    layout="wide",
)

st.title("🛒购物车演示")
st.markdown("使用session_state来实现购物车功能")

######========初始化购物车==========
if 'cart' not in st.session_state:
    st.session_state.cart = []


#========商品数据库============
PRODUCTS = {
    "苹果": {"price": 5,"unit": "斤"},
    "香蕉": {"price": 3,"unit": "斤"},
    "橙子": {"price": 4,"unit": "斤"},
    "西瓜": {"price": 10,"unit": "斤"},
    "葡萄": {"price": 43,"unit": "斤"},
    "欧亚": {"price": 6,"unit": "个"},
    "牛奶": {"price": 65,"unit": "瓶"},
    "面包": {"price": 34,"unit": "袋"},
    "鸡蛋": {"price": 7,"unit": "盒"},

}

############侧边栏添加商品

st.sidebar.header("添加商品到购物车")

#商品选择
produce_name = st.sidebar.selectbox("选择商品", 
                                    list(PRODUCTS.keys()),
                                    format_func=lambda x: f"{x} - {PRODUCTS[x]['price']}元/{PRODUCTS[x]['unit']}")
#数量选择
quantity = st.sidebar.number_input("数量", min_value=1, value=1, step=1)

#加入购物车
if st.sidebar.button("加入购物车",
                     use_container_width=True,
                     type="primary"):
    #将商品添加到购物车
    existing_index = None
    for index, item in enumerate(st.session_state.cart):
        if item['name'] == produce_name:
            existing_index = index
            break
    if existing_index is not None:
        st.session_state.cart[existing_index]['quantity'] += quantity
        st.sidebar.success(f"已将 {quantity} 个 {PRODUCTS[produce_name]['unit']} 加入购物车！")
else:
    st.session_state.cart.append({"name": produce_name, "quantity": quantity, "price": PRODUCTS[produce_name]["price"], "unit": PRODUCTS[produce_name]["unit"]})
    st.sidebar.success(f"{produce_name} 已加入购物车！")

##===主界面购物内容
st.header("购物车内容")

if st.session_state.cart:
    header_col1, header_col2, header_col3, header_col4,header_col5 = st.columns([4, 2, 2, 2, 1])
    with header_col1:
        st.write("商品名称")
    with header_col2:
        st.write("单价")
    with header_col3:
        st.write("数量")
    with header_col4:
        st.write("总价")
    with header_col5:
        st.write("操作")
    st.divider()

#显示购物车内容
    total = 0
    for i,item in enumerate(st.session_state.cart):
        col1, col2, col3, col4,col5 = st.columns([4, 2, 2, 2, 1])
        item_total =item["price"] * item["quantity"]
        total += item_total
        with col1:
            st.write(item["name"])
        with col2:
            st.write(f"{item['price']}元/{item['unit']}")
        with col3:
            new_quantity = st.number_input("数量", min_value=1, value=item["quantity"], label_visibility="collapsed", key=f"quantity_{i}")
            if new_quantity != item["quantity"]:
                st.session_state.cart[i]["quantity"] = new_quantity
                st.rerun()
        with col4:
            st.write(f"¥{item_total}")
        with col5:
            if st.button("删除", key=f"delete_{i}"):
                remove_item = st.session_state.cart.pop(i)
                st.success(f"{remove_item['name']} 已从购物车中删除！")
                st.rerun()
    ###总计区域
    st.markdown("### 结算")
    total_col1, total_col2, total_col3 = st.columns([3, 2, 2])
    with total_col1:
        st.info(f"**商品种类** {len(st.session_state.cart)}")
    with total_col2:
        total_items = sum(item["quantity"] for item in st.session_state.cart)
        st.info(f"**商品总数** {total_items}")
    with total_col3:
        st.metric("总计金额", f"¥{total}")

    # 操作按钮
    action_col1, action_col2= st.columns(2)
    with action_col1:
        if st.button("清空购物车", use_container_width=True, type="primary"):
            st.session_state.cart.clear()
            st.success("购物车已清空！")
            st.rerun()
    with action_col2:
        if st.button("结算", use_container_width=True, type="primary"):
            st.success(f"结算成功！总计金额：¥{total}")
            st.balloons()
else:
    st.info("购物车为空，请添加商品！")
    if st.button("去购物"):
        st.sidebar.expander('',expanded=True)
st.divider()
st.caption("本示例演示了如何使用Streamlit的session_state来实现购物车功能。")

