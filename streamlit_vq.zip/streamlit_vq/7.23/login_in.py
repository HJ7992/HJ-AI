import streamlit as st

st.set_page_config(
    page_title = '登录系统',
    page_icon = '🔒',
    layout='wide'
)
USERS  = {
    'admin': '123456',
    'user1': 'password1',
    'user2': 'password2',
    'user3': 'password3',
}

if 'login_in' not in st.session_state:
    st.session_state['login_in'] = False

if 'username' not in st.session_state:
    st.session_state['username'] = None


####################登录界面
if not st.session_state['login_in']:
    st.title('🔒 登录系统')
    st.markdown("""
    **测试账号：**
    - 管理员：admin / 123456
    - 用户 1：user1 / password1
    - 用户 2：user2 / password2
    """)
    with st.form("login_form"):
        col1, col2 = st.columns(2)
        with col1:
            username = st.text_input('用户名')

        with col2:
            password = st.text_input('密码', type='password', help='请输入密码')

        submit = st.form_submit_button('登录')

        if submit:
            if username in USERS and USERS[username] == password:
                st.session_state['login_in'] = True
                st.session_state['username'] = username
                st.success(f'登录成功，欢迎 {username}！')
                st.balloons()
                st.rerun()
            else:
                st.error('用户名或密码错误，请重试。')
else:
    ###侧边栏
    st.sidebar.title(f'{st.session_state["username"]}')
    st.sidebar.info('登陆状态:已登录')

    ###登出按钮
    if st.sidebar.button('登出'):
        st.session_state['login_in'] = False
        st.session_state['username'] = None
        st.success('已登出')
        st.rerun()
    st.divider()
    ##########显示所有用户(管理员)
    if st.session_state['username'] == 'admin':
        st.sidebar.subheader('所有用户信息')
        for user, pwd in USERS.items():
            st.sidebar.write(f'用户名: {user}, 密码: {pwd}')
    

    ###主界面内容
    st.title(f'欢迎使用登录系统，{st.session_state["username"]}!')
    st.markdown("""这是受保护的内容区域，只有登录用户才能查看。""")

    st.divider()
    ### 不同用户的不同内容
    if st.session_state['username'] == 'admin': 
        st.subheader('管理员专属内容')
        st.markdown("##  管理员面板")
        st.info("""您是管理员，可以访问所有功能和数据。
        **管理员权限：**
        - 查看所有用户
        - 修改系统设置
        - 访问敏感数据
        """)
        ###模拟用户管理
        st.subheader('用户管理')
        col1, col2,col3 = st.columns(3)
        with col1:
            st.metric('总用户数', len(USERS))
        with col2:
            st.metric('在线用户数', 1)  # 假设只有当前登录用户在线
        with col3:
            st.metric('管理员用户数', 1)  # 假设只有一个管理员
        st.subheader('系统设置')
        with st.form('settings_form'):
            maintenance_mode = st.checkbox('维护模式', value=False)
            allow_registration = st.checkbox('允许新用户注册', value=True)


            if st.form_submit_button('保存设置'):
                st.success('设置已保存')
                st.info(f'维护模式: {"开启" if maintenance_mode else "关闭"}，允许新用户注册: {"是" if allow_registration else "否"}')
    else:
        st.subheader('普通用户内容')
        st.markdown("##  用户面板")
        st.info("""您是普通用户，可以访问基本功能和数据。
        **普通用户权限：**
        - 查看个人信息
        - 修改个人设置
        - 访问非敏感数据
        """)
        info_col1, info_col2 = st.columns(2)
        with info_col1:
            st.metric('用户名', st.session_state['username'])
        with info_col2:
            user_type = "管理员" if st.session_state['username'] == 'admin' else "普通用户"
            st.info(f'用户类型: {user_type}')

            st.subheader('个人设置')
            func_col1, func_col2 = st.columns(2)
            with func_col1:
                if st.button('查看个人资料',use_container_width=True):
                    st.success('正在加载个人资料...')
            with func_col2:
                if st.button('个人设置',use_container_width=True):
                    st.warning('请联系管理员修改密码。')


