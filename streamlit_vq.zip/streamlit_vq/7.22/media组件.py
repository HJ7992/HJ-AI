import streamlit as st
import numpy as np
import PIL.Image as Image
st.set_page_config(
    page_title = '一个演示',
    page_icon = '',
    layout = 'centered',
    initial_sidebar_state = 'expanded',
)
st.header('媒体演示展示')

tab1, tab2,tab3,tab4 = st.tabs(['d','da','a','a'])
with tab1:
    col1,col2 = st.columns(2)
    with col1:
        st.header("图片上传")
        img_array = np.random.randint(0, 255, (100, 100, 3), dtype = np.uint8)
        print(img_array)
        img = Image.fromarray(img_array)

with tab2:
    st.header('音频播放')
    st.subheader('音频播放实例')
    st.markdown("""
    **实例音频**
    - 这是一个免费的实例音频文件
    """)
    try:
        st.audio(
            'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
            format='audio/mp3',
        )
    except:
        st.info("XXXXXXXXX")
    st.divider()

    st.subheader('上传音频文件')

    audio_file = st.file_uploader(
        "上传音频文件",
        type=["mp3","ogg","wav"],
        key = "audio_upload"
    )
    if audio_file is not None:
        st.audio(
            audio_file,
            format=f'audio/{audio_file.name.split(".")[-1]}',
        )
        st.success(f'正在播放{audio_file.name}')
with tab3:
    st.header('视频播放')
    st.subheader('视频播放实例')
    try:
        st.video()
    except:
        st.info("XXXXXXXXX")

    st.divider()
    st.subheader('上传视频实例')
    video_file =st.file_uploader(
        '上传视频文件',
        type=['mp4','AVI','wav'],
        key = 'video_upload'
    )
    if video_file is not None:
        st.video(
            video_file,
            width = 400
        )
        st.success('成功')
with tab4:
    st.header('代码展示')
    st.subheader(' py代码展示实例')
    py_code ="""
    st.set_page_config(
    page_title = '一个演示',
    page_icon = '',
    layout = 'centered',
    initial_sidebar_state = 'expanded',
)
st.header('媒体演示展示')

tab1, tab2,tab3,tab4 = st.tabs(['d','da','a','a'])
with tab1:
    col1,col2 = st.columns(2)
    with col1:
        st.header("图片上传")
        img_array = np.random.randint(0, 255, (100, 100, 3), dtype = np.uint8)
        print(img_array)
        img = Image.fromarray(img_array)
    """
    st.code(
        py_code,
        language = 'python',
        line_numbers = True,
    )

    st.divider()
    st.subheader(' 其它代码展示实例')
    col1,col2 = st.columns(2)
    with col1:
        st.markdown('**javascript**')
        js_code = """function hello(){
        console.log('hello');}"""
        st.code(js_code)

    with col2:
        st.markdown('**SQL**')
        

